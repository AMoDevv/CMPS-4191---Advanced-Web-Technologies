$(document).ready(function(){
	$('#readMoreButton').click(() =>{
		console.log("readMoreButton clicked");
		$('#moreParagraph').show();
	});
	
	$('#readLessButton').click(() => {
		$('#moreParagraph').hide();
	});
	
	$('#changingParagraph').hover(() =>{
		$('#changingParagraph').css("background-color", "green");
	});
	
	$('#submitButton').click(() => {
		let emailElement = document.getElementById("emailInput");
	if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(emailElement.value))
  {
    return (true)
  }
    alert("You have entered an invalid email address!")
    return (false)
	});
});
