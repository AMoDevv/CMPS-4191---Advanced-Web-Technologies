$(document).ready(() => {
$("#card1").hover(function () {
            // over
            $("#card1").addClass("hoverCard");
        }, function () {
            // out
            $("#card1").removeClass("hoverCard");
        }
    );

    $("#card2").hover(function () {
        // over
        $("#card2").addClass("hoverCard");
    }, function () {
        // out
        $("#card2").removeClass("hoverCard");
    }
);
$("#card3").hover(function () {
    // over
    $("#card3").addClass("hoverCard");
}, function () {
    // out
    $("#card3").removeClass("hoverCard");
}
);
})