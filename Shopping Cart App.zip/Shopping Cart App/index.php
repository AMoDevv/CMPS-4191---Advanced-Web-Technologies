<?php
session_start();
require_once './config.php';

if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("location: login.php");
    exit;
}
else{
    $out = array();
    $sql = "SELECT * FROM product";
    if($result = $mysqli->query($sql)){
        while ($row = $result -> fetch_object()) {
            array_push($out, $row);
        }
        $result -> free_result();
    }
    else{
        echo nl2br("\nERROR: Failed to execute $sql. " . mysqli_error($mysqli));
    }
    $userID = $_SESSION['user_id'];
    $cartsql = "SELECT * FROM shopping_cart WHERE user_id = $userID";
    $cartID = 0;
    if($result = $mysqli->query($cartsql)){
        $cartID = $result->fetch_object()->id;
    }
    else{
        echo nl2br("\nERROR: Failed to execute $sql. " . mysqli_error($mysqli));
    }

    $cartItemsSQL = "SELECT * FROM cart_item WHERE cart_id = $cartID";
    $cartItems = array();
    if($result = $mysqli->query($cartItemsSQL)){
        while($row = $result -> fetch_object()){
            array_push($cartItems, $row);
        }
        $result -> free_result();
    }
    $numOfItems = 0;
    foreach($cartItems as $item){
        $numOfItems += $item->quantity;
    }
}
?>

<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>Products</title>
  <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css'>
<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css'><link rel="stylesheet" href="css/product.css">
<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
  
</head>
<body>
<div class="alert alert-success" id='itemAddedAlert' role="alert" style='display:none;'>
  Item successfully added to cart!
</div>
    <p id="holdUserID" style="display:none;"><?php echo $_SESSION['user_id']?></p>
<!-- Navbar -->
<nav class="navbar navbar-expand-md navbar-light">

  <a class="navbar-brand" href="index.html">
    <img src="./images/deliverit.png"  height=75px; width = 75px; alt="mdb logo">
  </a>

  <!-- Collapse button -->
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#basicExampleNav1"
    aria-controls="basicExampleNav1" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <!-- Links -->
  <div class="collapse navbar-collapse" id="basicExampleNav1" style="position:absolute; right: 0px;">

    <!-- Right -->
    <ul class="navbar-nav ml-auto">
      <li class="nav-item" style='margin-right: 20px;'>
        <a href="checkout.php" class="nav-link navbar-link-2 waves-effect">
          <span class="badge badge-pill red" style='color:red'><p id='numberOfItemsInCart'><?php echo $numOfItems?></p></span>
          <i class="fas fa-shopping-cart pl-0"></i>
        </a>
      </li>
      <?php
      if($_SESSION==null){
        echo "<li class='nav-item'>
        <a href='#!' class='nav-link waves-effect'>
          Sign in
        </a>
      </li>
      <li class='nav-item pl-2 mb-2 mb-md-0'>
        <a href='signup.php' type='button'
          class='btn btn-outline-info btn-md btn-rounded btn-navbar waves-effect waves-light'>Sign up</a>
      </li>";
      }
      else{
        if($_SESSION['loggedin'] != true){
            echo "<li class='nav-item'>
            <a href='#!' class='nav-link waves-effect'>
              Sign in
            </a>
          </li>
          <li class='nav-item pl-2 mb-2 mb-md-0'>
            <a href='signup.php' type='button'
              class='btn btn-outline-info btn-md btn-rounded btn-navbar waves-effect waves-light'>Sign up</a>
          </li>";
        }
        else{
            echo"
            
            <li class='nav-item pl-2 mb-2 mb-md-0'>
            <a href='login.php?logout=true' type='button' id='logoutBtn'
              class='btn btn-outline-info btn-md btn-rounded btn-navbar waves-effect waves-light'>Log Out</a>
          </li>";
        }
    }
      ?>
    </ul>

  </div>
  <!-- Links -->

</nav>
<!-- Navbar -->
<section class="section-products">
		<div class="container">
				<div class="row justify-content-center text-center">
						<div class="col-md-8 col-lg-6">
								<div class="header">
										<h2>Popular Products</h2>
								</div>
						</div>
				</div>
				<div class="row">
                    <?php 
                        for($x = 0; $x < sizeof($out); $x++){
                            $id = $x+1;
                            echo "
                            <div class='col-md-6 col-lg-4 col-xl-4'>
								<div id='product$id' class='single-product'>
										<div class='part-1'>
												<ul>
														<li><a href='#' id='addToCart$id'><i  class='fas fa-plus'></i></a></li>
												</ul>
										</div>
										<div class='part-2'>
												<h3 class='product-title'>".$out[$x]->product_name."</h3>
												<h4 class='product-price'>$".$out[$x]->price."</h4>
										</div>
								</div>
						</div>
                            ";
                        }
                    ?>
						
				</div>
		</div>
</section>
<!-- partial -->
  
</body>
<script src="js/products.js"></script>
</html>
