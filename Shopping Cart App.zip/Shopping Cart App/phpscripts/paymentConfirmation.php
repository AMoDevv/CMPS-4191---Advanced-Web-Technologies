<?php 
session_start();

require_once '../config.php';

$firstName = $_POST['firstName'];
$lastName = $_POST['lastName'];
$username = $_POST['username'];
$email = $_POST['email'];
$address = $_POST['address'];
$country = $_POST['country'];
$district = $_POST['district'];
$town = $_POST['town'];
$cc_name = $_POST['cc-name'];
$cc_number = $_POST['cc-number'];
$cc_cvv = $_POST['cc-cvv'];
$cc_expiration = $_POST['cc-expiration'];


$obj;
$obj->firstName = $firstName;
$obj->lastName = $lastName;
$obj->username = $username;
$obj->email = $email;
$obj->address = $address;
$obj->country = $country;
$obj->district = $district;
$obj->town = $town;
$obj->cc_name = $cc_name;
$obj->cc_number = $cc_number;
$obj->cc_cvv = $cc_cvv;
$obj->cc_expiration = $cc_expiration;

echo $firstName;
echo $lastName;
echo $username;
echo $email;
echo $address;
echo $country;
echo $district;
echo $town;
echo $cc_name;
echo $cc_number;
echo $cc_cvv;
echo $cc_expiration;

?>