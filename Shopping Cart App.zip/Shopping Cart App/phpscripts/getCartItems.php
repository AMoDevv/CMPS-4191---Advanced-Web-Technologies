<?php 
session_start();

require_once '../config.php';

    $userid = $_POST['userID'];
    $productID = $_POST['productID'];
    $cartsql = "SELECT * FROM shopping_cart WHERE user_id = $userid";
    $cartID = 0;
    if($result = $mysqli->query($cartsql)){
        $cartID = $result->fetch_object()->id;
    }
    else{
        echo nl2br("\nERROR: Failed to execute $sql. " . mysqli_error($mysqli));
    }

    $checkForItemSQL = "SELECT * FROM cart_item WHERE product_id = $productID";
    if($result = $mysqli->query($checkForItemSQL)){
        $resultSet = $result->fetch_object();
        if($resultSet != null){
            $updateItemQuantitySQL = "UPDATE cart_item SET quantity = quantity + 1 WHERE product_id = $productID";
            if($result = $mysqli->query($updateItemQuantitySQL)){

            }
            else{
                echo nl2br("\nERROR: Failed to execute $checkForItemSQL. " . mysqli_error($mysqli));
            }
        }
        else{
            $insertItemSQL = "INSERT INTO cart_item (
                cart_id,
                product_id,
                quantity
            )
            VALUES(
                $cartID,
                $productID,
                1
            )";
        
            if($result = $mysqli->query($insertItemSQL)){
        
            }
        
        }
    }
    $cartItemsSQL = "SELECT * FROM cart_item WHERE cart_id = $cartID";
    $cartItems = array();
    if($result = $mysqli->query($cartItemsSQL)){
        while($row = $result -> fetch_object()){
            array_push($cartItems, $row);
        }
        $result -> free_result();
    }
    $numOfItems = 0;
    foreach($cartItems as $item){
        $numOfItems += $item->quantity;
    }
    echo $numOfItems;


?>