<?php 
session_start();

require_once '../config.php';

$userName = $_POST['username'];
$password = $_POST['password'];

$sql = "INSERT INTO user(
    username,
    password
)
VALUES(
    '$userName',
    '$password'
)";

if(mysqli_query($mysqli, $sql)){
    echo nl2br("\nUser added successfully to users table.");
    $userID = $mysqli->insert_id;

    $sql = "INSERT INTO shopping_cart(
        user_id,
        total
    )
    VALUES(
        $userID,
        0
    )";

    if(mysqli_query($mysqli, $sql)){
        echo nl2br("\nShopping cart successfully created.");
        header("location: ../login.php");
    }

}
else {
    echo nl2br("\nERROR: Failed to execute $sql. " . mysqli_error($mysqli));
  }
?>