CREATE DATABASE IF NOT EXISTS shoppingcartapp;
USE shoppingcartapp;

CREATE TABLE `user` (
    `user_id` int(11) NOT NULL,
    `username` varchar(50) NOT NULL,
    `password` varchar(255) NOT NULL,
    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE `product` (
    `product_id` int(11) NOT NULL,
    `product_name` varchar(255) NOT NULL,
    `price` decimal NOT NULL
);

CREATE TABLE `shopping_cart` (
    `id` int(11) NOT NULL,
    `user_id` int(11) NOT NULL,
    `total` decimal NOT NULL
);

CREATE TABLE `cart_item` (
    `id` int(11) NOT NULL,
    `cart_id` int(11) NOT NULL,
    `product_id` int(11) NOT NULL,
    `quantity` int NOT NULL
);

ALTER TABLE `user`
ADD PRIMARY KEY (`user_id`),
MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `product`
ADD PRIMARY KEY (`product_id`),
MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `shopping_cart`
ADD PRIMARY KEY (`id`),
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `cart_item`
ADD PRIMARY KEY (`id`),
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,
ADD CONSTRAINT `cart_id_FK` FOREIGN KEY (`cart_id`) REFERENCES `shopping_cart` (`id`),
ADD CONSTRAINT `product_id_FK` FOREIGN KEY (`product_id`) REFERENCES `product` (`product_id`);
