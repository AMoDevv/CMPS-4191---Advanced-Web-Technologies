<?php
require_once 'config.php';
session_start();

$user_id = $_SESSION['user_id'];

$cartsql = "SELECT * FROM shopping_cart WHERE user_id = $user_id";
$cartID = 0;
if($result = $mysqli->query($cartsql)){
    $cartID = $result->fetch_object()->id;
}
else{
    echo nl2br("\nERROR: Failed to execute $sql. " . mysqli_error($mysqli));
}

$cartItemsSQL = "SELECT * FROM cart_item WHERE cart_id = $cartID";
$cartItems = array();
if($result = $mysqli->query($cartItemsSQL)){
    while($row = $result -> fetch_object()){
        array_push($cartItems, $row);
    }
    $result -> free_result();
}

$numOfItems = 0;
    foreach($cartItems as $item){
        $numOfItems += $item->quantity;
    }

  $itemPrices = array();
  $itemNames = array();
  $ctr = 0;
  $cartTotal = 0;
  foreach($cartItems as $item){
    $sql = "SELECT * FROM product WHERE product_id = $item->product_id";
    $result = $mysqli->query($sql);
    $obj = $result->fetch_object();
    $cartTotal += $obj->price * $item->quantity;
    $itemPrices[$ctr] = $obj->price;
    $itemNames[$ctr] = $obj->product_name;
    $ctr +=1;
  }
  $tax = $cartTotal * 0.125;
  $total = $cartTotal +$tax;
?>
<!doctype html>
<html>
  <head>
    <meta charset="utf-8">

    <title>AMoDev Solutions</title>

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link href="style.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="js/script.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js" integrity="sha512-GsLlZN/3F2ErC5ifS5QtgpiJtWd43JWSuIgh7mbzZ8zBps+dvLusV+eNQATqgA/HdeKFVgA5v3S/cIrLF7QnIg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
  </head>

  <body>
    <div id="receiptFormat" style='position: absolute;top:0;left:-999px;z-index:10;'>
      <center><h2>AMoDev Solutions</h3></center>
      <center><h4>Thank you for placing an order.</h3></center>
      <br><br>
      <center><h4>Order Details</h4></center>
      <div class='row'>
        <div class='col-md-6' id='fullNameDetail'>
          Full Name:
        </div>
        <div class='col-md-6' id='emailDetail'>
          Bill To: 
        </div>
        <div class='col-md-6' id='addressDetail'>
          Address: 
        </div>
        <div class='col-md-6' id='totalDetail'>
          Total:
        </div>
      </div>
      
    </div>
    <div class="container">
      <br>
      <div class="text-center">
        <h2>AMoDev Solutions Checkout</h2>
        <p >Thank you for your interest in purchasing our products. Kindly fill out the checkout form to proceed with your order.</p>
      </div>
      <br><br>

      <div class="row">
        <div class="col-md-4 order-md-2 mb-4">
          <?php 
          echo"<h4 class='d-flex justify-content-between align-items-center mb-3'>
            <span>Your cart</span>
            <span>$numOfItems</span>
              </h4>
              ";
          echo "<ul class='list-group mb-3'>";
          $ctr = 0;
            foreach($cartItems as $item){
              $itemTotal = $item->quantity * $itemPrices[$ctr];
              $itemName = $itemNames[$ctr];
              $ctr+=1;
              echo "<li class='list-group-item d-flex justify-content-between'>
              <div>
                <h6 class='my-0'>$itemName</h6>
                <small class='text-info'>"."Quantity: ".$item->quantity."</small>
              </div>
              <span class='text-info'>"."$".$itemTotal."</span>
            </li>";
            }
          echo "</ul>";
          ?>
          
          
            
            <li class="list-group-item d-flex justify-content-between bg-light" style="display:none !important;" id="promoListItem">
              <div class="text-success">
                <h6 class="my-0">Promo code</h6>
                <small>HALLOWEEN</small>
              </div>
              <span class="text-success">-$15</span>
            </li>
            <li class="list-group-item d-flex justify-content-between">
              <span>Subtotal</span>
              <strong id='cartSubTotal'><?php echo "$".$cartTotal?></strong>
              
            </li>
            <li class="list-group-item d-flex justify-content-between">
            <span>GST</span>
              <strong id='tax'><?php echo "$".$tax?></strong>
            </li>

            <li class="list-group-item d-flex justify-content-between">
            <span>Total</span>
              <strong id='cartTotal'><?php echo "$".$total?></strong>
            </li>
          </ul>

          <div class="card">
            <div>
              <input type="text" class="form-control" placeholder="Promo code" id="promoCode">
              <div>
                <button id="redeemPromoButton" class="btn btn-secondary" style="width:100%">Redeem</button>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-8">
          <h4 class="mb-4">Billing address</h4>
          <form id='paymentForm'>
            <div class="row">
              <div class="col-md-6 mb-4">
                <label for="firstName">First name</label>
                <input type="text" class="form-control inputFieldHoverFN" id="firstName" placeholder="" value="" required>
                
              </div>
              <div class="col-md-6 mb-3">
                <label for="lastName">Last name</label>
                <input type="text" class="form-control inputFieldHoverLN" id="lastName" placeholder="" value="" required>
               
              </div>
            </div>

            <div class="mb-4">
              <label for="username">Username</label>
              <div class="input-group" style="width:290px;">
                <input type="text" class="form-control inputFieldHoverUN" id="username" placeholder="Username" required>
                
              </div>
            </div>

            <div class="mb-4">
              <label for="email">Email</label>
              <input type="email" class="form-control inputFieldHoverEM" id="email" placeholder="you@example.com" style="width:290px;">
              
            </div>

            <div class="mb-4">
              <label for="address">Address</label>
              <input type="text" class="form-control inputFieldHoverAD" style="width:290px;"id="address" placeholder="1234 Main St" required>
              
            </div>


            <div class="row">
              <div class="col-md-5 mb-3">
                <label for="country">Country</label>
                <select class="custom-select d-block w-100" id="country"  required>
                  <option selected>Belize</option>
                </select>
              </div>
              <div class="col-md-4 mb-3">
                <label for="state">District</label>
                <select class="custom-select d-block w-100" id="district" required>
                  <option>Belize</option>
                  <option selected>Cayo</option>
                  <option>Corozal</option>
                  <option>Orange Walk</option>
                  <option>Stann Creek</option>
                  <option>Toledo</option>
                </select>
              </div>
              <div class="col-md-3 mb-3">
                <label for="zip">Town/City/Village</label>
                <input type="text" class="form-control" id="town" placeholder="" required>
                
              </div>
            </div>
            <hr class="mb-4">
            <div class="custom-control custom-checkbox">
              <input type="checkbox" class="custom-control-input" id="save-info">
              <label class="custom-control-label" for="save-info">Save this information for next time</label>
            </div>
            <hr class="mb-4">

            <h4 class="mb-3">Payment</h4>

            <div class="d-block my-3">
              <div class="custom-control custom-radio">
                <input id="credit" name="paymentMethod" type="radio" class="custom-control-input" checked required>
                <label class="custom-control-label" for="credit">Credit card</label>
              </div>
              <div class="custom-control custom-radio">
                <input id="debit" name="paymentMethod" type="radio" class="custom-control-input" required>
                <label class="custom-control-label" for="debit">Debit card</label>
              </div>
              <div class="custom-control custom-radio">
                <input id="paypal" name="paymentMethod" type="radio" class="custom-control-input" required>
                <label class="custom-control-label" for="paypal">Paypal</label>
              </div>
            </div>
            <div class="row">
              <div class="col-md-6 mb-3">
                <label for="cc-name">Name on card</label>
                <input type="text" class="form-control" id="cc-name" placeholder="" required>
                <small class="text-muted">Full name as displayed on card</small>
              
              </div>
              <div class="col-md-6 mb-3">
                <label for="cc-number">Credit card number</label>
                <input type="text" class="form-control" id="cc-number" placeholder="" required>
                
              </div>
            </div>
            <div class="row">
              <div class="col-md-3 mb-3">
                <label for="cc-expiration">Expiration</label>
                <input type="text" class="form-control" id="cc-expiration" placeholder="MM/YY" required>
                
              </div>

              
              <div class="col-md-3 mb-3">
                <label for="cc-expiration">CVV</label>
                <input type="text" class="form-control" id="cc-cvv" placeholder="" required>
                
              </div>
            </div>
            <hr class="mb-4">
            <button class="btn btn-primary" type="button" id="checkoutButton">Confirm Payment</button>
          </form>
        </div>
      </div>

      <footer class="my-5 pt-5 text-muted text-center text-small">
        <p>&copy; 2021-2022 AMoDev Solutions</p>
      </footer>
    </div>

  </body>
  <script src="js/checkout.js"></script>
</html>