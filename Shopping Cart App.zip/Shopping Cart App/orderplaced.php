<?php
session_start();
require_once './config.php';

?>

<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>Order Placed</title>
  <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css'>
<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css'><link rel="stylesheet" href="css/product.css">
<script src="vendor/jquery/jquery-3.2.1.min.js"></script>

<script>
    function goHome(){
        window.location.href="index.php";
    }
</script>
</head>
<body>

<center><h1>Your Order has been placed!</h1></center>
<center></h4>Order receipt has also been downloaded.</h4>
<center><button onclick="goHome()">Home</button></center>
  
</body>
</html>
