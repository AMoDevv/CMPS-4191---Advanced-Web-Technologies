$(document).ready(async function(){
    console.log('connected');
    $('#checkoutButton').click( async function(){
        let validForm = true;

        if($('#firstName').val().trim() == ""){
            validForm = false;
            alert("Please enter a valid first name, cannot be empty");
        }
        else if($('#lastName').val().trim() == ""){
            validForm = false;
            alert("Please enter a valid last name, cannot be empty");
        }
        else if($('#username').val().trim() == ""){
            validForm = false;
            alert("Please enter a valid username, cannot be empty");
        }
        else if($('#email').val().trim() == "" || !/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test($('#email').val())){
            validForm = false;
            alert("Please enter a valid email, cannot be empty");
        }
        else if($('#address').val().trim() == ""){
            validForm = false;
            alert("Please enter a valid address, cannot be empty");
        }
        else if($('#town').val().trim() == ""){
            validForm = false;
            alert("Please enter a valid town/city/village, cannot be empty");
        }
        else if($('#cc-name').val().trim() == ""){
            validForm = false;
            alert("Please enter a valid name on card, cannot be empty");
        }
        else if($('#cc-number').val().trim() == ""){
            validForm = false;
            alert("Please enter a valid credit card number, cannot be empty");
        }
        else if($('#cc-cvv').val().trim() == ""){
            validForm = false;
            alert("Please enter a valid CVV, cannot be empty");
        }
        else if($('#cc-expiration').val().trim() == ""){
            validForm = false;
            alert("Please enter a valid expiration date for card, cannot be empty");
        }
    
        if(validForm == true){
            $('#fullNameDetail').html('Full Name: '+ $('#firstName').val().trim() +' '+$('#lastName').val().trim());
            $('#emailDetail').html('Bill To: '+ $('#email').val().trim());
            $('#addressDetail').html('Address: '+ $('#address').val()+ ', ' +$('#district').val());
            $('#totalDetail').html('Total: '+$('#cartTotal').html);

            var element = document.getElementById('receiptFormat').innerHTML;
            console.log(element);
            var fileName = 'order-receipt';
            var opt = {
                margin: 1,
                filename: fileName,
                image: {type: 'jpeg', quality: 0.98},
                html2canvas: {scale: 2},
                jsPDF:{unit: 'in', format: 'letter', orientation:'portrait'}
            }
            await html2pdf(element, opt);
            window.location.href = "orderplaced.php";

            // $.ajax({
            //     type: "POST",
            //     url: './phpscripts/paymentConfirmation.php',
            //     data: {
            //         'firstName':$('#firstName').val().trim(),
            //         'lastName':$('#lastName').val().trim(),
            //         'username':$('#username').val().trim(),
            //         'email':$('#email').val().trim(),
            //         'address':$('#address').val().trim(),
            //         'country':$('#country :selected').text(),
            //         'district':$('#district :selected').text(),
            //         'town':$('#town').val().trim(),
            //         'cc-name':$('#cc-name').val().trim(),
            //         'cc-number':$('#town').val().trim(),
            //         'cc-cvv':$('#cc-cvv').val().trim(),
            //         'cc-expiration':$('#cc-expiration').val().trim()
                    
            // },
            //     success: function(response){
            //         console.log(response);
            //     },
            //     error: function(){
            //         console.log("error");
            //     }
            // });
        }
    })
});