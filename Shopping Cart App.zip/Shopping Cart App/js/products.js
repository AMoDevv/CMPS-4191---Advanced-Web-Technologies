

$('#addToCart1').click(function(){
    $.ajax({
        type: "POST",
        url: './phpscripts/getCartItems.php',
        data: {
            'userID':document.getElementById('holdUserID').innerHTML,
            'productID':1
    },
        success: function(response){
            $('#numberOfItemsInCart').html(response);
            $('#itemAddedAlert').show().delay(2000).fadeOut();
        }
    });
});

$('#addToCart2').click(function(){
    $.ajax({
        type: "POST",
        url: './phpscripts/getCartItems.php',
        data: {
            'userID':document.getElementById('holdUserID').innerHTML,
            'productID':2
    },
        success: function(response){
            $('#numberOfItemsInCart').html(response);
            $('#itemAddedAlert').show().delay(2000).fadeOut();
        }
    });
});
$('#addToCart3').click(function(){
    $.ajax({
        type: "POST",
        url: './phpscripts/getCartItems.php',
        data: {
            'userID':document.getElementById('holdUserID').innerHTML,
            'productID':3
    },
        success: function(response){
            $('#numberOfItemsInCart').html(response);
            $('#itemAddedAlert').show().delay(2000).fadeOut();
        }
    });
});
$('#addToCart4').click(function(){
    $.ajax({
        type: "POST",
        url: './phpscripts/getCartItems.php',
        data: {
            'userID':document.getElementById('holdUserID').innerHTML,
            'productID':4
    },
        success: function(response){
            $('#numberOfItemsInCart').html(response);
            $('#itemAddedAlert').show().delay(2000).fadeOut();
        }
    });
});
$('#addToCart5').click(function(){
    $.ajax({
        type: "POST",
        url: './phpscripts/getCartItems.php',
        data: {
            'userID':document.getElementById('holdUserID').innerHTML,
            'productID':5
    },
        success: function(response){
            $('#numberOfItemsInCart').html(response);
            $('#itemAddedAlert').show().delay(2000).fadeOut();
        }
    });
});
$('#addToCart6').click(function(){
    $.ajax({
        type: "POST",
        url: './phpscripts/getCartItems.php',
        data: {
            'userID':document.getElementById('holdUserID').innerHTML,
            'productID':6
    },
        success: function(response){
            $('#numberOfItemsInCart').html(response);
            $('#itemAddedAlert').show().delay(2000).fadeOut();
        }
    });
});