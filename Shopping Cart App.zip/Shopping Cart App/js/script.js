$(document).ready(function(){

    $('#redeemPromoButton').click(function (){
        if($('#promoCode').val() == "HALLOWEEN"){
            $('#promoListItem').css("display", "list-item");
        }
    });

    $('.inputFieldHoverFN').hover(function () {
            $('.inputFieldHoverFN').css("background-color", "#5bc0de");
            
        }, function () {
            $('.inputFieldHoverFN').css("background-color", "white");
        }
    );

    $('.inputFieldHoverLN').hover(function () {
        $('.inputFieldHoverLN').css("background-color", "#5bc0de");
        
    }, function () {
        $('.inputFieldHoverLN').css("background-color", "white");
        }
    );

    $('.inputFieldHoverUN').hover(function () {
        $('.inputFieldHoverUN').css("background-color", "#5bc0de");
        
    }, function () {
        $('.inputFieldHoverUN').css("background-color", "white");
        }
    );

    $('.inputFieldHoverEM').hover(function () {
        $('.inputFieldHoverEM').css("background-color", "#5bc0de");
        
    }, function () {
        $('.inputFieldHoverEM').css("background-color", "white");
        }
    );

    $('.inputFieldHoverAD').hover(function () {
        $('.inputFieldHoverAD').css("background-color", "#5bc0de");
        
    }, function () {
        $('.inputFieldHoverAD').css("background-color", "white");
        }
    );


    $('#cc-expiration').on("input", function () {
        console.log("cc-expiration is being changed");
        if($('#cc-expiration').val().length == 2){
            let input = document.getElementById("cc-expiration");
            input.append("/");
        }
    });

        

  
});